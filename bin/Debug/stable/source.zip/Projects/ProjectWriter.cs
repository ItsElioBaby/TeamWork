﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace twlib.Projects
{
    public class ProjectWriter
    {
        private StringBuilder Comments;
        private StringBuilder Files;
        private StringBuilder Properties;

        private string file;

        public ProjectWriter(string name, string projFile)
        {
            Comments = new StringBuilder();
            Files = new StringBuilder();
            Properties = new StringBuilder();
            file = projFile;
            WriteProperty("Name", name);
        }

        public void WriteComment(string comment)
        {
            Comments.AppendLine("//" + comment);
        }

        public void WriteFile(string fileName)
        {
            Files.AppendLine("File='" + fileName + "'");
        }

        public void WriteProperty(string propertyName, string propertyValue)
        {
            Properties.AppendLine(propertyName + "=" + propertyValue);
        }

        private byte[] GetProjectBytes()
        {
            Q1.RRR.BasicQ1BinaryFormation bfmt = new Q1.RRR.BasicQ1BinaryFormation();
            string comments = Comments.ToString(),
                files = Files.ToString(),
                properties = Properties.ToString();
            string dataStr = comments + "\n\r" + properties + "\n\r" + files + "\n\r";
            return bfmt.Patch(Encoding.ASCII.GetBytes(dataStr));
        }

        public void Flush()
        {
            File.WriteAllBytes(file, GetProjectBytes());
        }
    }
}
