﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace twlib.Projects
{
    public class ProjectFile
    {
        private string data;
        private string[] lines_t;

        public ProjectFile(string projFile)
        {
            byte[] edata = File.ReadAllBytes(projFile);
            /*Q1.RRR.BasicQ1BinaryFormation bfmt = new Q1.RRR.BasicQ1BinaryFormation();
            byte[] ddata = bfmt.DePatch(edata);*/
            lines_t = File.ReadAllLines(projFile); //ddata.Split('\n');
            ClearDataFromComments();
        }

        private void ClearDataFromComments()
        {
            string nData = "";
            for (int i = 0; i < lines_t.Length; i++)
            {
                string line = lines_t[i];
                if (line.Contains("//"))
                {
                    line = line.Remove(line.IndexOf("//"));
                }
                nData += line + Environment.NewLine;
            }
            lines_t = nData.Split('\n');
        }

        public string[] GetData(string propertyName)
        {
            List<string> files = new List<string>();
            for (int i = 0; i < lines_t.Length; i++)
            {
                if (lines_t[i].Contains(propertyName))
                {
                    files.Add(lines_t[i].Replace(propertyName + "=", "").Replace("'", ""));
                }
            }
            return files.ToArray();
        }

        public string[] GetFileNames()
        {
            return GetData("File");
        }

        public string ProjectName { get { return GetData("Name")[0]; } }
        public string[] Authors { get { return GetData("Authors")[0].Split(','); } }
        public string Website { get { return GetData("Website")[0]; } }
        public string Description { get { return GetData("Description")[0]; } }
        public string Language { get { return GetData("Language")[0]; } }
        public string MasterKey { get { return GetData("MasterKey")[0]; } }
    }
}
