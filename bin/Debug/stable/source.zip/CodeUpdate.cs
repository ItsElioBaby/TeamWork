﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace twlib
{
    [Serializable]
    public class CodeUpdateTemplate
    {
        public string Author;
        public long Date;
        public string Code;
        public string File;
    }
}
