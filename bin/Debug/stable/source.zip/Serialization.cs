﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization.Formatters.Soap;

namespace twlib
{
    public static class Serialization
    {
        public static byte[] BinarySerialize(object o)
        {
            MemoryStream memsr = new MemoryStream();
            BinaryFormatter fmt = new BinaryFormatter();
            fmt.Serialize(memsr, o);
            return memsr.ToArray();
        }

        public static byte[] SoapSerialize(object o)
        {
            MemoryStream memsr = new MemoryStream();
            SoapFormatter fmt = new SoapFormatter();
            fmt.Serialize(memsr, o);
            return memsr.ToArray();
        }

        public static object BinaryDeserialize(byte[] b)
        {
            MemoryStream memsr = new MemoryStream(b);
            BinaryFormatter fmt = new BinaryFormatter();
            return fmt.Deserialize(memsr);
        }

        public static object SoapDeserialize(byte[] b)
        {
            MemoryStream memsr = new MemoryStream(b);
            SoapFormatter fmt = new SoapFormatter();
            return fmt.Deserialize(memsr);
        }
    }
}
