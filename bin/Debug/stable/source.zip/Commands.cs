﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace twlib
{
    //Used to send requests to the server.
    [Serializable]
    public class UserCommand
    {
        private string command;
        private string[] args;
        private Int64 key;

        public string Command { get { return command; } }
        public string[] Arguments { get { return args; } }
        public Int64 Key { get { return key; } }

        public UserCommand(string cmd, string[] _args, Int64 k)
        {
            command = cmd;
            args = _args;
            key = k;
        }
    }

    //Used to send server responses to the client.
    [Serializable]
    public class ServerResponse
    {
        private bool _ok;
        private Int64 key;
        private string response_string;
        private byte[] respose_data;

        public bool OK { get { return _ok; } }
        public Int64 Key { get { return key; } }
        public string ResponseString { get { return response_string; } }
        public byte[] ResponseData { get { return respose_data; } }

        public ServerResponse(bool k, Int64 pKey, string rs, byte[] rd)
        {
            _ok = k;
            key = pKey;
            response_string = rs;
            respose_data = rd;
        }
    }
}
